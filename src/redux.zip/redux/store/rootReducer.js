import {reducer as authReducer} from "../slice/auth";
import {combineReducers} from "@reduxjs/toolkit";

export const rootReducer = combineReducers({
   auth:authReducer,

});
